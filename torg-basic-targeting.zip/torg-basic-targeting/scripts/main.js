// Transcrypt'ed from Python, 2021-05-28 21:10:28
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __proxy__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, abs, all, any, assert, bool, bytearray, bytes, callable, chr, copy, deepcopy, delattr, dict, dir, divmod, enumerate, filter, float, getattr, hasattr, input, int, isinstance, issubclass, len, list, map, max, min, object, ord, pow, print, property, py_TypeError, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
var __name__ = '__main__';
export var MODULE_NAME = 'torg-basic-targeting';
export var get_token_or_actor_from_message = function (message) {
	var actor = null;
	if (message.data.speaker.token) {
		var token = canvas.tokens.get (message.data.speaker.token);
		if (token) {
			var actor = token.actor;
		}
	}
	if (!(token)) {
		var actor = game.actors.get (message.data.speaker.actor);
	}
	return actor;
};
export var find_skill = function (actor, string) {
	for (var skill of Object.keys (actor.data.data.skills)) {
		if (string == game.i18n.localize ('torgeternity.skills.' + skill)) {
			return skill;
		}
	}
};
export var modify_message = function (message, html) {
	if (!(game.user.isGM)) {
		return ;
	}
	var roll_result_html = html.find ('.skill-roll-result');
	try {
		var roll_result = int (roll_result_html.text ());
	}
	catch (__except0__) {
		if (isinstance (__except0__, ValueError)) {
			return ;
		}
		else {
			throw __except0__;
		}
	}
	var target_html = ' <i class="fas fa-crosshairs tbt-crosshair"></i>';
	roll_result_html.append (target_html);
	var chat_title = html.find ('.skill-chat-title').text ();
	var skill = find_skill (get_token_or_actor_from_message (message), chat_title.__getslice__ (0, -(5), 1));
	var show_defenses = function (event) {
		if (!(canvas)) {
			return ;
		}
		if (canvas.tokens.controlled.lenght < 1) {
			return ;
		}
		var DEFENSES = ['dodge', 'meleeWeapons', 'unarmedCombat', 'intimidation', 'maneuver', 'taunt', 'trick'];
		var content = '<p>Resultado: {}</p>'.format (roll_result);
		for (var token of canvas.tokens.controlled) {
			content += '<p>{}</p>'.format (token.actor.data.name);
			var skills = dict (token.actor.data.data.skills);
			for (var defense of DEFENSES) {
				var trans_skill = game.i18n.localize ('torgeternity.skills.' + defense);
				var current_skill = skills.py_get (defense);
				var result_margin = roll_result - current_skill.value;
				if (result_margin >= 10) {
					var result_color = 'tbt-best';
				}
				else if (result_margin >= 5) {
					var result_color = 'tbt-great';
				}
				else if (result_margin > 0) {
					var result_color = 'tbt-success';
				}
				else {
					var result_color = 'tbt-fail';
				}
				content += '- {} ({}) = <strong class="{}">{}</strong><br>'.format (trans_skill, current_skill.value, result_color, result_margin);
			}
		}
		var chatData = dict ([['user', game.user._id], ['type', CONST.CHAT_MESSAGE_TYPES.OOC], ['whisper', ChatMessage.getWhisperRecipients ('GM')], ['speaker', ChatMessage.getSpeaker ()], ['content', content]]);
		ChatMessage.create (chatData);
	};
	html.find ('.tbt-crosshair').click (show_defenses);
};
export var on_ready = function () {
	print ('Torg basic targeting is active');
};
Hooks.once ('ready', on_ready);
Hooks.on ('renderChatMessage', modify_message);

//# sourceMappingURL=main.map